import logo from './logo.svg';
import './App.css';
import Home from './component/home/home';

function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
