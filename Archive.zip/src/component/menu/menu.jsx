import React, { Component }  from "react";

export default class Menu extends Component {
    render(){
        return <div className={this.props.active === this.props.name ? "menuItem active" : "menuItem"} onClick = {this.props.handler}>{this.props.name}</div>
    }
}
