import React, { Component }  from "react";
import moment from 'moment'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../../css/style.css'
import '../../css/responsive.css'
import Menu from "../menu/menu";
import Weather from "../weather/weather";
var result = [];
for (var i=0; i<5; i++) {
    var d = new Date();
    d.setDate(d.getDate() + i);
    result.push(moment(d).format("YYYY-MM-DD 06:00:00"))
    result.join(',')
}
export default class Home extends Component {
    constructor(){
        super()
        this.state = {
            active:'OTTAWA',
            cityId:6094817,
            lat: 45.4112, 
            lon: -75.6981,
            todayData:{},
            weatherData:[],
            data:[
                { id: 6094817, menu:'OTTAWA', lat: 45.4112, lon: -75.6981},
                { id: 524901, menu:'MOSCOW', lat: 55.7522, lon: 37.6156 },
                { id: 1850147, menu:'TOKYO', lat: 35.689, lon: 139.6917 },
            ]
        }
    }
    menuClick (item) {
        this.setState({
            active: item.menu,
            cityId:item.id
        })
        this.getWeatherData(item.id)
        this.getTodayData(item.lat, item.lon)
    }
    componentDidMount() {
        this.getWeatherData(this.state.cityId)
        this.getTodayData(this.state.lat, this.state.lon)
    }
    getWeatherData = (id) => {
        fetch(`http://api.openweathermap.org/data/2.5/forecast?id=${id}&appid=3d3a04786c4caacc9a2e74f7c7e5b1f3`)
        .then((res) => res.json())
        .then((data) => {
            let filterArray = data.list.filter(item => result.includes(item.dt_txt)).map((value) => value)
            console.log('filterArray...', filterArray)
            this.setState({
                weatherData: filterArray
            })
        })
        .catch((err) => console.log('err..', err))
    }
    getTodayData = (lat, lon) => {
        fetch(`https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=3d3a04786c4caacc9a2e74f7c7e5b1f3`)
        .then((res) => res.json())
        .then((data) => {
           let item = {
                weather : data.weather[0].description,
                icon: data.weather[0].icon,
                temp: parseInt(data.main.temp-273.15)
            }
            this.setState({
                todayData: item
            })
        })
        .catch((err) => console.log('err..', err))
    }
    render(){
        return(
            <div className="container">
                <div className="coverWrap">
                    <div className="menu">
                        {this.state.data.map((item) => (
                            <Menu name={item.menu} handler={() => this.menuClick(item)} active={this.state.active}/>
                        ))}
                    </div>
                    <Weather data={this.state.todayData} weatherData={this.state.weatherData}/>
                </div>
            </div>
        )
    }
}