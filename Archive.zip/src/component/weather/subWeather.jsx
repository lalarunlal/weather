import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {  faCloud } from '@fortawesome/free-solid-svg-icons'
import moment from 'moment'

export default class Subweather extends Component {
    render() {
        return (
            <React.Fragment>
                <div className='dayWeather'>
                    <h2>{moment(this.props.data.dt_txt).format("ddd")}</h2>
                    <div className='dayWeaterImg'>
                        <FontAwesomeIcon icon={faCloud} />
                    </div>
                    <div className='todayWeaterValue'>
                        <h3>{parseInt(this.props.data.main.temp-273.15)}<sup>0</sup></h3>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}