import React, { Component }  from "react";
import Subweather from "./subWeather";
import Todayweather from "./todayWeather";
export default class Weather extends Component {
    render(){
        return(
            <div className="weatherCover">
                <Todayweather data={this.props.data}/>
                <div className="weatherSubWrap">
                    {this.props.weatherData.map((item) => (
                        <Subweather data={item}/>
                    ))}
                </div>
            </div>
        )
    }
}
