import React from 'react';
import ReactWeather, { useOpenWeather } from 'react-open-weather';
import { OpenWeatherMap } from 'react-weather';

function Todayweather() {
    const { data, isLoading, errorMessage } = useOpenWeather({
        key: '8a78b84062754a66aa902536222811',
        lat: '48.137154',
        lon: '11.576124',
        lang: 'en',
        unit: 'metric', // values are (metric, standard, imperial)
    });
    console.log('data...', data)
    console.log('isLoading...', isLoading)
    console.log('errorMessage...', errorMessage)
    return (
        <div>
            lal
            <OpenWeatherMap city="Jerusalem" country="IL" appid="8a78b84062754a66aa902536222811" />
            {/* <ReactWeather
                isLoading={isLoading}
                errorMessage={errorMessage}
                data={data}
                lang="en"
                locationLabel="Munich"
                unitsLabels={{ temperature: 'C', windSpeed: 'Km/h' }}
                showForecast
            /> */}
        </div>
    );
}

export default Todayweather;