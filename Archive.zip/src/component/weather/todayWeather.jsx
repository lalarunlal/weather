import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import {  faCloud } from '@fortawesome/free-solid-svg-icons'

export default class Todayweather extends Component {
    render() {
        return (
            <React.Fragment>
                <div className='todayBanner'>
                    <h2>Today</h2>
                    <div className='todayWeater'>
                        <div className='todayWeaterImg'>
                            <FontAwesomeIcon icon={faCloud} />
                        </div>
                        <div className='todayWeaterValue'>
                            <h1>{this.props.data.temp}<sup>0</sup>C</h1>
                            <p>{this.props.data.weather}</p>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        );
    }
}